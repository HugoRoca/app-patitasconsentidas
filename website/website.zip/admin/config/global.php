<?php

//ip de la pc del servidor de la base de datos
define("DB_HOST", "localhost");

//Nombre de la base de datos
define("DB_NAME", "ago24pad_patitasconsentidas");

//Usuario de la base de datos
define("DB_USERNAME","ago24pad_hroca");

//Contraseña del usuario de la ase de datos
define("DB_PASSWORD","AZQ*iY#{Z~F&");

//Definimos la codificación de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","PatitasConsentidas");

?>